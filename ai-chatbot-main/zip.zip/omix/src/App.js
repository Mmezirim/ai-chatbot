import Chat from './chat.js'
import React from 'react';
import Header from './components/Header';
import MatrixCanvas from './components/MatrixCanvas';
import Terminal from './components/Terminal';
import Milestones from './components/Milestones';
import Cards from './components/Cards';
import './App.css';

function App() {
  return (
    <div>
      <Header />
      <MatrixCanvas />
      <div className="container">
        <h1>AZI TERMINAL</h1>
        <Cards />
        <Terminal />
        <Milestones />
        {/* <Chat /> */}
      </div>
    </div>
  );
}

export default App;