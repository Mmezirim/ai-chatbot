import React from 'react';

const Header = () => (
  <div className="logo-container">
    <a href=" " target="_blank" rel="noopener noreferrer">
      <img src="images/whitepaper.png" alt="Whitepaper Icon" />
    </a>
    <a href=" " target="_blank" rel="noopener noreferrer">
      <img src="images/twitter.png" alt="Twitter Icon" />
    </a>
    <a href=" " target="_blank" rel="noopener noreferrer">
      <img src="images/telegram.png" alt="Telegram Icon" />
    </a>
    <a href=" " target="_blank" rel="noopener noreferrer">
      <img src="images/pumpfun.png" alt="PumpFun Icon" />
    </a>
  </div>
);

export default Header;