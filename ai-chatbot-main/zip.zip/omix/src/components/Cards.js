import React from 'react';

const Cards = () => (
  <div className="grid">
    <div className="card">
      <h2>AZI MEDICINES</h2>
      <div className="egg-container">
        <div className="egg" onClick={() => alert('Specimen #1337: [PUMPFUN SIGNATURE DETECTED]')}></div>
        <div className="egg" onClick={() => alert('Specimen #2048: [DEXSCREENER ANOMALY PRESENT]')}></div>
        <div className="egg" onClick={() => alert('Specimen #4096: [BULLISH SHIFT OBSERVED]')}></div>
      </div>
    </div>
  </div>
);

export default Cards;