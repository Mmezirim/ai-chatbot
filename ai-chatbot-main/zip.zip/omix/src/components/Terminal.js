import React from 'react';

const Terminal = () => (
  <div id="terminal">
    <div id="output"></div>
    <div id="input">
      <span>&gt; </span>
      <input
        type="text"
        id="commandInput"
        placeholder="Type a command..."
        autoComplete="off"
      />
    </div>
  </div>
);

export default Terminal;