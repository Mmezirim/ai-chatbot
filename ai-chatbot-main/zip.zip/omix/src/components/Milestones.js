import React from 'react';

const milestones = [
  {
    title: 'Phase 1: AZI Foundation',
    details: '- Set up initial infrastructure. Build the AZI Terminal prototype. Early testing with a focus on medical and crypto integration.',
  },
  {
    title: 'Phase 2: Crypto Integration',
    details: '- Integrate with blockchain for smart contracts. Add portfolio management tools for traders. Deploy tokenomics and rewards system.',
  },
  // Add more milestones as needed
];

const Milestones = () => (
  <div className="card">
    <h2>AZI Milestones</h2>
    <div className="milestone-timeline">
      {milestones.map((milestone, index) => (
        <div key={index} className="milestone">
          <strong>{milestone.title}</strong>
          <div className="milestone-details">{milestone.details}</div>
        </div>
      ))}
    </div>
  </div>
);

export default Milestones;
